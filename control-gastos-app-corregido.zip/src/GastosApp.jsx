import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from "recharts";

const categorias = ["Alquiler", "Comida", "Transporte", "Salud", "Entretenimiento", "Educación", "Otros"];
const colores = ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0", "#9966FF", "#FF9F40", "#8DD1E1"];

export default function GastosApp() {
  const [gastos, setGastos] = useState(() => JSON.parse(localStorage.getItem("gastos") || "[]"));
  const [desc, setDesc] = useState("");
  const [monto, setMonto] = useState("");
  const [cat, setCat] = useState(categorias[0]);
  const [ingreso, setIngreso] = useState(() => parseFloat(localStorage.getItem("ingreso")) || 0);
  const [metaAhorro, setMetaAhorro] = useState(() => parseFloat(localStorage.getItem("metaAhorro")) || 0);

  // Guardar en localStorage cuando se actualiza
  useEffect(() => {
    localStorage.setItem("gastos", JSON.stringify(gastos));
  }, [gastos]);

  useEffect(() => {
    localStorage.setItem("ingreso", ingreso);
  }, [ingreso]);

  useEffect(() => {
    localStorage.setItem("metaAhorro", metaAhorro);
  }, [metaAhorro]);

  const agregarGasto = () => {
    if (!desc || !monto || isNaN(parseFloat(monto))) return;
    setGastos([...gastos, { descripcion: desc, monto: parseFloat(monto), categoria: cat, fecha: new Date().toISOString().split("T")[0] }]);
    setDesc("");
    setMonto("");
  };

  const total = gastos.reduce((sum, g) => sum + g.monto, 0);
  const ahorro = ingreso - total;
  const ahorroPorcentaje = ingreso > 0 ? (ahorro / ingreso) * 100 : 0;
  const metaCumplida = metaAhorro > 0 && ahorro >= metaAhorro;

  const resumen = categorias.map((cat, idx) => {
    const totalCat = gastos.filter(g => g.categoria === cat).reduce((sum, g) => sum + g.monto, 0);
    return { name: cat, value: totalCat, fill: colores[idx] };
  }).filter(r => r.value > 0);

  return (
    <div className="p-4 max-w-4xl mx-auto grid gap-6">
      <Card>
        <CardContent className="p-4 grid gap-4">
          <h2 className="text-xl font-bold">💸 Ingreso y Meta</h2>
          <Input type="number" placeholder="Ingreso mensual" value={ingreso} onChange={e => setIngreso(parseFloat(e.target.value))} />
          <Input type="number" placeholder="Meta de ahorro" value={metaAhorro} onChange={e => setMetaAhorro(parseFloat(e.target.value))} />
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 grid gap-4">
          <h2 className="text-xl font-bold">🧾 Agregar Gasto</h2>
          <Input placeholder="Descripción" value={desc} onChange={e => setDesc(e.target.value)} />
          <Input placeholder="Monto" value={monto} onChange={e => setMonto(e.target.value)} />
          <select value={cat} onChange={e => setCat(e.target.value)} className="border p-2 rounded">
            {categorias.map(c => <option key={c}>{c}</option>)}
          </select>
          <Button onClick={agregarGasto}>Agregar</Button>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <h2 className="text-xl font-bold mb-4">📊 Resumen de Gastos</h2>
          <p className="font-medium">Total Gastado: ${total.toFixed(2)}</p>
          <p className="font-medium">Ahorro Estimado: ${ahorro.toFixed(2)} ({ahorroPorcentaje.toFixed(1)}%)</p>
          <p className={`font-medium ${metaCumplida ? "text-green-600" : "text-red-600"}`}>
            {metaCumplida ? "🎯 ¡Meta de ahorro cumplida!" : "🔔 Meta de ahorro no alcanzada"}
          </p>
          <ul className="mt-2 space-y-1">
            {gastos.map((g, i) => (
              <li key={i} className="flex justify-between text-sm">
                <span>{g.descripcion} ({g.categoria})</span>
                <span>${g.monto.toFixed(2)}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 h-96">
          <h2 className="text-xl font-bold mb-4">🧁 Gráfico de Gastos</h2>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={resumen} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                {resumen.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.fill} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}